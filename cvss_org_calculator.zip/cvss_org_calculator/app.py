from __future__ import annotations

import json
from datetime import datetime, timezone

import streamlit as st

from cvss_engine import BASE_METRICS, calculate_base_score

st.set_page_config(page_title="Organization CVSS v4.0 Calculator", page_icon="🛡️", layout="wide")

st.title("CVSS v4.0 Base Score Calculator")
st.caption("Internal tool starter · CVSS Base Score only · scoring powered by the cvss Python library")
st.info(
    "This tool calculates the standards-based CVSS v4.0 Base Score. Keep organization-specific risk, "
    "asset criticality, exploit intelligence, and remediation SLAs as separate fields/policies; "
    "do not silently change the CVSS score."
)

BASE_CHOICES = {
    "AV": {"N": "Network", "A": "Adjacent", "L": "Local", "P": "Physical"},
    "AC": {"L": "Low", "H": "High"},
    "AT": {"N": "None", "P": "Present"},
    "PR": {"N": "None", "L": "Low", "H": "High"},
    "UI": {"N": "None", "P": "Passive", "A": "Active"},
    "VC": {"H": "High", "L": "Low", "N": "None"},
    "VI": {"H": "High", "L": "Low", "N": "None"},
    "VA": {"H": "High", "L": "Low", "N": "None"},
    "SC": {"H": "High", "L": "Low", "N": "None"},
    "SI": {"S": "Safety", "H": "High", "L": "Low", "N": "None"},
    "SA": {"S": "Safety", "H": "High", "L": "Low", "N": "None"},
}
METRIC_LABELS = {
    "AV": "Attack Vector (AV)",
    "AC": "Attack Complexity (AC)",
    "AT": "Attack Requirements (AT)",
    "PR": "Privileges Required (PR)",
    "UI": "User Interaction (UI)",
    "VC": "Vulnerable System Confidentiality (VC)",
    "VI": "Vulnerable System Integrity (VI)",
    "VA": "Vulnerable System Availability (VA)",
    "SC": "Subsequent System Confidentiality (SC)",
    "SI": "Subsequent System Integrity (SI)",
    "SA": "Subsequent System Availability (SA)",
}
DEFAULTS = {"AV": "N", "AC": "L", "AT": "N", "PR": "N", "UI": "N",
            "VC": "H", "VI": "H", "VA": "H", "SC": "N", "SI": "N", "SA": "N"}


def show_result(vector: str) -> None:
    try:
        result = calculate_base_score(vector)
    except ValueError as exc:
        st.error(str(exc))
        return

    left, right, third = st.columns([1, 1, 2])
    left.metric("CVSS v4.0 Base Score", f"{result.base_score:.1f} / 10.0")
    right.metric("Severity", result.severity)
    with third:
        st.write("**Canonical vector**")
        st.code(result.canonical_vector, language=None)
        st.caption("Select the vector text above to copy it. The JSON export also includes the vector.")

    export_data = {
        "standard": "CVSS v4.0",
        "score_type": "Base Score",
        "base_score": result.base_score,
        "severity": result.severity,
        "vector": result.canonical_vector,
        "calculated_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "calculator": "Organization CVSS v4.0 Calculator",
    }
    st.download_button(
        "Download result as JSON",
        data=json.dumps(export_data, indent=2),
        file_name="cvss-v4-base-score.json",
        mime="application/json",
    )


form_tab, vector_tab, notes_tab = st.tabs(["Choose metrics", "Paste vector", "Deployment notes"])

with form_tab:
    st.subheader("Base metrics")
    st.write("Choose a value for each of the 11 required Base Metrics, then calculate.")
    with st.form("metric_form"):
        values = {}
        cols = st.columns(3)
        for i, metric in enumerate(BASE_METRICS):
            options = list(BASE_CHOICES[metric].keys())
            with cols[i % 3]:
                values[metric] = st.selectbox(
                    METRIC_LABELS[metric],
                    options=options,
                    index=options.index(DEFAULTS[metric]),
                    format_func=lambda x, m=metric: f"{x} — {BASE_CHOICES[m][x]}",
                    key=f"metric_{metric}",
                )
        submitted = st.form_submit_button("Calculate Base Score", type="primary")
    if submitted:
        vector = "CVSS:4.0/" + "/".join(f"{metric}:{values[metric]}" for metric in BASE_METRICS)
        show_result(vector)

with vector_tab:
    st.subheader("Paste a CVSS v4.0 Base vector")
    default_vector = "CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N"
    with st.form("vector_form"):
        pasted_vector = st.text_input("Vector string", value=default_vector, help="This tab accepts exactly the 11 Base Metrics; other metric groups are intentionally rejected.")
        vector_submitted = st.form_submit_button("Validate and calculate", type="primary")
    if vector_submitted:
        show_result(pasted_vector)

with notes_tab:
    st.subheader("Before internal deployment")
    st.markdown(
        """
        - **Keep scoring and company policy separate.** If you add asset tier, internet exposure, known exploitation, or compensating controls, display them as separate context or an organization-priority result—not as a modified CVSS Base Score.
        - **Validate against FIRST test vectors.** Use the reference set before production release and on every scoring-library upgrade.
        - **Pin and review dependencies.** Lock the `cvss` and Streamlit versions in your approved environment; review the package license and update process.
        - **Preserve audit context.** Store the input/canonical vector, score, severity, timestamp, tool version, and assessor/change history if you add persistence.
        - **Use attribution.** CVSS is owned by FIRST. Include attribution and the vector when publishing or exporting scores.
        """
    )
    st.markdown("**References**")
    st.markdown("- [FIRST CVSS v4.0 specification](https://www.first.org/cvss/v4.0/specification-document)")
    st.markdown("- [FIRST CVSS v4.0 FAQ and validation guidance](https://www.first.org/cvss/v4.0/faq)")
    st.markdown("- [CVSS Python library documentation](https://pypi.org/project/cvss/)")
    st.markdown("- [FIRST CVSS validation vectors](https://github.com/FIRSTdotorg/cvss-resources)")

st.divider()
st.caption("CVSS is owned by FIRST and used here by permission. Always retain the complete vector with the numeric score.")
