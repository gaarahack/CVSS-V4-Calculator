"""Base-only CVSS v4.0 wrapper for an internal calculator.

Scoring is delegated to the `cvss` package rather than reimplementing the
CVSS v4.0 MacroVector lookup/interpolation algorithm in this project.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from cvss import CVSS4

BASE_METRICS = ("AV", "AC", "AT", "PR", "UI", "VC", "VI", "VA", "SC", "SI", "SA")


@dataclass(frozen=True)
class ScoreResult:
    input_vector: str
    canonical_vector: str
    base_score: float
    severity: str


def calculate_base_score(vector: str) -> ScoreResult:
    """Validate a CVSS v4.0 Base-only vector and return its score.

    This deliberately rejects Threat, Environmental, and Supplemental metrics
    so the displayed value cannot be mistaken for a contextual score.
    """
    if not isinstance(vector, str) or not vector.strip():
        raise ValueError("Enter a CVSS v4.0 vector.")

    cleaned_input = vector.strip()
    if not cleaned_input.startswith("CVSS:4.0/"):
        raise ValueError("Vector must start with 'CVSS:4.0/'.")

    parts = cleaned_input.split("/")
    metrics: Dict[str, str] = {}
    for part in parts[1:]:
        if ":" not in part:
            raise ValueError(f"Invalid vector component: '{part}'. Expected KEY:VALUE.")
        key, value = part.split(":", 1)
        if key in metrics:
            raise ValueError(f"Duplicate metric '{key}'.")
        metrics[key] = value

    unknown = sorted(set(metrics) - set(BASE_METRICS))
    if unknown:
        raise ValueError(
            "This calculator is Base-only. Remove non-Base metric(s): " + ", ".join(unknown)
        )

    missing = [key for key in BASE_METRICS if key not in metrics]
    if missing:
        raise ValueError("Missing required Base metric(s): " + ", ".join(missing))

    try:
        calculator = CVSS4(cleaned_input)
        # The exact 11-metric restriction above means this is the CVSS Base Score.
        scores = calculator.scores()
        severities = calculator.severities()
        if not scores or not severities:
            raise ValueError("The CVSS library did not return a score.")
        score = float(scores[0])
        severity = str(severities[0])
        canonical = calculator.clean_vector()
    except Exception as exc:
        # Keep library-specific exception classes out of the UI layer.
        raise ValueError(f"Invalid CVSS v4.0 vector: {exc}") from exc

    return ScoreResult(
        input_vector=cleaned_input,
        canonical_vector=canonical,
        base_score=score,
        severity=severity,
    )
