import pytest

from cvss_engine import calculate_base_score


@pytest.mark.parametrize(
    ("vector", "expected_score", "expected_severity"),
    [
        (
            "CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N",
            9.3,
            "Critical",
        ),
        (
            "CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H/SC:H/SI:H/SA:N",
            9.9,
            "Critical",
        ),
    ],
)
def test_known_vectors(vector, expected_score, expected_severity):
    result = calculate_base_score(vector)
    assert result.base_score == expected_score
    assert result.severity == expected_severity
    assert result.canonical_vector.startswith("CVSS:4.0/")


def test_rejects_missing_base_metric():
    with pytest.raises(ValueError, match="Missing required Base metric"):
        calculate_base_score("CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H/SC:N/SI:N")


def test_rejects_threat_or_environmental_metrics():
    vector = "CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N/E:A"
    with pytest.raises(ValueError, match="Base-only"):
        calculate_base_score(vector)


def test_rejects_duplicate_metric():
    vector = "CVSS:4.0/AV:N/AV:A/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N"
    with pytest.raises(ValueError, match="Duplicate metric"):
        calculate_base_score(vector)
