# Organization CVSS v4.0 Base Score Calculator

A small internal Streamlit application for calculating the **standards-based CVSS v4.0 Base Score**. It provides a form for the 11 Base Metrics, a vector-string input, a canonical vector, severity, and a JSON export.

## Why it uses a library

CVSS v4.0 scoring is based on MacroVector lookup and interpolation rather than a simple weighted-sum formula. This starter delegates scoring to the `cvss` Python package and does not implement an approximate formula. The UI rejects Threat, Environmental, and Supplemental metrics so the displayed number is specifically the Base Score.

## Run locally

Use Python 3.10+ in a virtual environment:

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
streamlit run app.py
```

Open the local URL printed by Streamlit. The app does not save submitted vectors to a database; JSON downloads are user-initiated.

## Run tests

```bash
python -m pip install pytest
pytest -q
```

The test suite includes known vectors and basic validation errors. Before production deployment, expand validation using the reference vectors from the [FIRST CVSS resources repository](https://github.com/FIRSTdotorg/cvss-resources), and compare results to the [official FIRST calculator](https://www.first.org/cvss/calculator/v4-0).

## Organization-specific features

Add organization context as separate fields (for example, asset tier, internet exposure, active exploitation, exploit intelligence, compensating controls, and remediation SLA). If you create an internal prioritization score, label it **Organization Priority** and document/version its formula. Do not overwrite or relabel the CVSS Base Score.

For any persistent storage, retain at least the vector string, score, severity, timestamp, assessor, app/library version, and audit history. Pin dependency versions in your organization's lockfile before production rollout.

## Attribution and licensing

CVSS is owned by FIRST. Include appropriate attribution and distribute the vector string together with the score. The `cvss` Python package is licensed under LGPLv3+; review license obligations for your deployment model. This project is a starter template, not a certification that the implementation has passed FIRST's complete validation suite.

## Official references

- [FIRST CVSS v4.0 specification](https://www.first.org/cvss/v4.0/specification-document)
- [FIRST CVSS v4.0 FAQ and calculator validation guidance](https://www.first.org/cvss/v4.0/faq)
- [cvss Python package](https://pypi.org/project/cvss/)
- [FIRST CVSS validation resources](https://github.com/FIRSTdotorg/cvss-resources)
